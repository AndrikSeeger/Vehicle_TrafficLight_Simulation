/**
 *  The content of this header can be customized.
 *  Any definitions in this file will be visible to all generated source files.
 *  This file will not be overridden by the ASCET code generator.
 */
#ifndef ESDL_USERCFG_H
#define ESDL_USERCFG_H

/* put your code here */

#endif /* ESDL_USERCFG_H */
