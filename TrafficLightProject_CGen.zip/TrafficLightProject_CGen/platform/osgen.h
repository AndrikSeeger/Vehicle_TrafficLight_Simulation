/*
 * Automatically generated output. DO NOT EDIT!!!
 * Configuration tool spec level 5, code level 0, revision 5
 * Target is "VRTA", revision 0
 * Tool built at 13:17:55 on Jul  3 2012
 * Build level is extended
 * Project is 'conf'
 * Last edited 'unknown'
 * File generated 'Mon Apr 11 18:07:47 2022'
 * Target variant 'MinGW'
 */
#ifndef __OS_GEN_H__
#define __OS_GEN_H__


#ifdef OS_RTK_FILE_INCLUDED
#error Illegal multiple header file inclusion
#else
#define OS_RTK_FILE_INCLUDED
#endif


#ifndef OSGEN_BUILD

extern struct os_resource OS_L002D;
#define osek_resource_RES_SCHEDULER (&OS_L002D)

#endif /* OSGEN_BUILD */


#endif /* __OS_GEN_H__ */

