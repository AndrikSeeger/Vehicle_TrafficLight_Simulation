#ifndef ESDL_PLATFORM_DEFS_H
#define ESDL_PLATFORM_DEFS_H
/**
 * Copyright ETAS GmbH, Stuttgart, Germany. All rights reserved.
 *
 * version 2.1
 *
 * This header file is used for PC experiment
 */
#include "esdl_types.h"
#include "esdl_deltaTimeDefs.h"

#endif /* ESDL_PLATFORM_DEFS_H */
